#!/usr/bin/env bash
set -euo pipefail
cd /home/oslamelon/Desktop/Projects/spica
OUT=outputs/alignment_verification_20260906_093823_82c6461
export LD_LIBRARY_PATH="/run/opengl-driver/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
.venv/bin/python - <<'PY'
import json
from pathlib import Path
p=Path('outputs/alignment_verification_20260906_093823_82c6461')
for arm in ('R','MD','MS'):
    r=json.loads((p/'smoke'/arm/'run_result.json').read_text())
    assert r['runtime']['updates_this_run']==50
    if arm!='R':
        assert r['gradient_calibration']['calibration_batch_replay_verified']
PY
LAMBDA=$(.venv/bin/python -c "import json; c=json.load(open('$OUT/calibration/calibration.json')); assert c['status']=='VALID'; print(c['calibration']['lambda_alignment_mean'])")
COMMON=(seed=42 device=cuda experiment_manifest_path="$OUT/corrected_pilot_manifest_v2.json" run_kind=pilot max_steps=1800 'probe_steps=[0,100,500,1000,1800]' log_every=100 lambda_alignment_covariance=0.0)
run() {
  local label=$1; shift
  test ! -e "$OUT/pilot/$label"
  (set -x; direnv exec . env LD_LIBRARY_PATH="$LD_LIBRARY_PATH" uv run --frozen --no-sync spica-train-alignment "${COMMON[@]}" "$@" hydra.run.dir="$OUT/pilot/$label") > "$OUT/logs/pilot_$label.log" 2>&1
  printf 'EXIT_CODE=0\n' >> "$OUT/logs/pilot_$label.log"
}
run R experiments=alignment_control lambda_alignment_mean=0.0
run MD experiments=alignment_mean_text_log lambda_alignment_mean="$LAMBDA" alignment_calibration_artifact="$OUT/calibration/calibration.json"
run MS experiments=alignment_mean_text_log_symmetric lambda_alignment_mean="$LAMBDA" alignment_calibration_artifact="$OUT/calibration/calibration.json"
printf 'PILOT_COMPLETED\n'
