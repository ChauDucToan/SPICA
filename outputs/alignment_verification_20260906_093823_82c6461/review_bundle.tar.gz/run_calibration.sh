#!/usr/bin/env bash
set -euo pipefail
cd /home/oslamelon/Desktop/Projects/spica
OUT=outputs/alignment_verification_20260906_093823_82c6461
export LD_LIBRARY_PATH="/run/opengl-driver/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
test ! -e "$OUT/calibration/calibration.json"
set -x
direnv exec . env LD_LIBRARY_PATH="$LD_LIBRARY_PATH" uv run --frozen --no-sync spica-train-alignment \
  experiments=alignment_mean_text_log seed=42 device=cuda \
  experiment_manifest_path="$OUT/corrected_pilot_manifest_v2.json" \
  run_kind=pilot max_steps=1800 'probe_steps=[0,100,500,1000,1800]' log_every=100 \
  lambda_alignment_mean=1.0 lambda_alignment_covariance=0.0 calibration_only=true \
  hydra.run.dir="$OUT/calibration"
